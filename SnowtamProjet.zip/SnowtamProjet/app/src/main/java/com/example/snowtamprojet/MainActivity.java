package com.example.snowtamprojet;

import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
Spinner spinner;
Button ajout;
Button valider;
boolean existe=false;
int compt=1;
    EditText text;
    Toast toast;
    List<String> listAdd = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addItemsOnSpinner();
        ajout=findViewById(R.id.ajout);
        valider=findViewById(R.id.valider);
        ajout.setOnClickListener(new View.OnClickListener() {
            LinearLayout layout = (LinearLayout)findViewById(R.id.layout);
            @Override
            public void onClick(View v) {
for(String a: listAdd){
    if(spinner.getSelectedItem().toString().equals(a.toString())){
        existe=true;
    }
}
                if(compt>5){
                    toast = Toast.makeText(getApplicationContext(), "you can't add more choice", Toast.LENGTH_SHORT);

                    toast.show();
                }
else if(existe==true){
    toast = Toast.makeText(getApplicationContext(), "you can't add ", Toast.LENGTH_SHORT);

    toast.show();
    existe=false;

}
                else{
                            TextView tv = new TextView(MainActivity.this);
                            tv.setText(spinner.getSelectedItem().toString());
                            layout.addView(tv);
                            listAdd.add(spinner.getSelectedItem().toString());
                            compt++;
                }
                    }



        });

    }


    public void addItemsOnSpinner() {

        spinner = (Spinner) findViewById(R.id.spinner);
        List<String> list = new ArrayList<String>();

        list.add("Orly");
        list.add("Charles de Gaulle");
        list.add("Nantes");
        list.add("Orly1");
        list.add("Charles de Gaulle1");
        list.add("Nantes1");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
    }
}
